﻿window.khesht = {
    config: {
        name: 'Khesht',
        version: '1.0.0',
        paths: {
            async: '3rd-party/require/plugin/async',
            stylesheet: '3rd-party/require/plugin/css',
            jquery: '3rd-party/jquery',
            nprogress: '3rd-party/nprogress/nprogress.min',
            bootstrap: '3rd-party/bootstrap/js/bootstrap',
            'jquery.form': '3rd-party/jquery.form'
        }
    }
};